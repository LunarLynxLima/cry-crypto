from rsa import check_padding

"""
Takes a ciphertext, public modulus and public exponent as input as input
PARAMS:
ciphertext: a list of integers of size 128 bytes
N: the public modulus of size 128 bytes
e: the public exponent
"""
def attack(cipher_text, N, e):
    """
    TODO: Implement your code here
    """
    

    """
    Return a list of integers representing the original message
    """
    return []
