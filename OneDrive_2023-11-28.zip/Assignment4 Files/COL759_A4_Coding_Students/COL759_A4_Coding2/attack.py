"""
You can define helper function here if you want
"""

def attack(N, e, msg):
    """
    write the code below
    """
    

    """
    return a signature (integer) corresponding to the given message that will get get verified
    """
    return 0